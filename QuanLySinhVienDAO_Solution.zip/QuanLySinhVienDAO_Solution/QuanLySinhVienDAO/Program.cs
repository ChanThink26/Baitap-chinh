using Microsoft.EntityFrameworkCore;
using QuanLySinhVienDAO;
using QuanLySinhVienDAO.Entity;

Console.OutputEncoding = System.Text.Encoding.UTF8;

using var db = new QLSVDBContext();
db.Database.Migrate();   // tạo database từ Migrations nếu chưa có (giống update-database)

if (!db.Categories.Any())
{
    var vanHoc = new Category { Name = "Văn học" };
    var chiPheo = new Book { Title = "Chí Phèo", Author = "Nam Cao", Category = vanHoc };
    db.Books.Add(chiPheo);
    db.BookCopies.Add(new BookCopy { Barcode = "CP-0001", Location = "Kệ A1", Book = chiPheo });
    db.BookCopies.Add(new BookCopy { Barcode = "CP-0002", Location = "Kệ A1", Book = chiPheo, IsBorrowed = true });
    db.SaveChanges();
}

foreach (var b in db.Books.Include(b => b.Category).Include(b => b.Copies).ToList())
    Console.WriteLine($"{b.Title} - {b.Author} [{b.Category!.Name}] | {b.Copies.Count} bản, còn {b.Copies.Count(c => !c.IsBorrowed)}");

Console.ReadLine();
