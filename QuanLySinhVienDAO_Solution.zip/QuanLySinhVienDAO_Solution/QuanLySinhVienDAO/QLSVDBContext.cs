using Microsoft.EntityFrameworkCore;
using QuanLySinhVienDAO.Entity;

namespace QuanLySinhVienDAO;

public class QLSVDBContext : DbContext
{
    public DbSet<Category> Categories { get; set; }
    public DbSet<Book> Books { get; set; }
    public DbSet<BookCopy> BookCopies { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
    {
        optionsBuilder.UseSqlite("Data Source=QuanLyThuVien.db");
    }
}
